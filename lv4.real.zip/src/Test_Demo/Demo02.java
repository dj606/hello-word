package Test_Demo;


import java.util.Scanner;


    public class Demo02 {
        static String str1 = "您点的菜是：";//定义字符串变量，提示已经点过的菜单
        static int i = 0;    //这个i没啥用，
        static double sum = 0.0;//定义所以菜品的总和为0.0

        public static void Index() {//定义初始页方法Index
            System.out.println("=========点餐系统=========");
            System.out.println("序号：1)       查看菜单");
            System.out.println("序号：2)       查看已点");
            System.out.println("序号：3)       合计费用");
            System.out.println("序号：4)       支付方式");
            System.out.println("序号：5)退出");
            System.out.print("请输入序号：");
        }


        public static void CaiDan() {
            System.out.println("欢迎来到国民饭店");
            System.out.println("======菜单=====");
            System.out.println("序号：10)      辣子鸡丁    38￥");
            System.out.println("序号：20)      水煮肉片    22￥");
            System.out.println("序号：30)      糖醋里脊    18￥");
            System.out.println("序号：40)      干锅牛肉    38￥");
            System.out.println("序号：50)      干锅排骨    29￥");

            System.out.print("请输入序号：");
            Scanner sc = new Scanner(System.in);//获取用户输入
            double in = sc.nextDouble();//将用户的输入定义到in
            if (in == 10) {
                System.out.println("你点的是：辣子鸡丁    38￥");
                sum = sum + 38;//添加菜品的单价
                str1 = str1 + "【辣子鸡丁】";//增加已点的菜单
                i = i + 1;
                Index();
            } else if (in == 20) {
                System.out.println("你点的是：水煮肉片    22￥");
                sum = sum + 22;
                str1 = str1 + "【水煮肉片】";
                i = i + 1;
                Index();
            } else if (in == 30) {
                System.out.println("你点的是：糖醋里脊    18￥");
                sum = sum + 18;
                str1 = str1 + "【糖醋里脊】";
                i = i + 1;
                Index();
            } else if (in == 40) {
                System.out.println("你点的是：干锅牛肉    38￥");
                sum = sum + 38;
                str1 = str1 + "【干锅牛肉】";
                i = i + 1;
                Index();
            } else if (in == 50) {
                System.out.println("你点的是：干锅排骨    29￥");
                sum = sum + 29;
                str1 = str1 + "【干锅排骨】";
                i = i + 1;
                Index();
            } else if (in == 5) {//用户输入5退出循环
                Demo01.boo = false;
                System.out.println("正在退出点餐系统.....");
            }
        }


        public static void YiDian() {
            System.out.println(str1);//输出已经点的菜单

        }

        public static void HeJi() {
            System.out.println("合计金额" + sum);//输出合计金额

        }

        public static void ZhiFu() {
            System.out.println("01) 支付宝");
            System.out.println("02) 微信");
            System.out.println("03) 人脸识别"); //输出支付方式

            System.out.print("请输入序号：");
            Scanner sc = new Scanner(System.in);//获取用户输入
            double on = sc.nextDouble();//将用户的输入定义到on
            if (on == 01) {
                System.out.println("请输出付款码......");
                Index();
            } else if (on == 02) {
                System.out.println("请输出付款码......");
                Index();
            } else if (on == 02) {
                System.out.println("请注视摄像头......");
                Index();
            } else if (on == 5) {//用户输入5退出循环
                Demo01.boo = false;
                System.out.println("正在退出点餐系统.....");
            }
        }
    }




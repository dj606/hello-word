package Test_Demo;

import java.util.Scanner;

import static Test_Demo.Demo02.Index;

public class Demo01 {static boolean boo=true;	//创建公共的布尔变量boo
    public static void main(String[] args) {
        Index();//调用Demo02下的Index首页方法
        k();//调用k方法，用于判断用户输入
    }
    public static void k(){//新建方法k
        while (boo) {//while循环，条件是boo==true
            Scanner sc = new Scanner(System.in);//使Scanner用键盘作为输入，然后用new在内存中实例化一个Scanner出来
            int in = sc.nextInt();//输入的整数类型等于in
            if (in ==1) {//判断输入的数是否等于1
                Demo02.CaiDan();//如果输入的数是1，则调用菜单
            } else if (in == 2) {//判断是否输入的数是2
                Demo02.YiDian();//若是2，则调用已经点过的菜单
            } else if (in == 3) {//判断输入的数字是否是3
                Demo02.HeJi();//若是则调用合计方法，计算菜单总和
            }else if (in == 4) {//判断输入的数字是否是4
                Demo02.ZhiFu();//若是则调用支付方法
            }else if(in==5){//若输入的数字为5
                boo=false;//则boo等于false。则终止循环
                System.out.println("正在退出点餐系统.....");
            }
        }
    }
}
